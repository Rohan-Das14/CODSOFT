from flask import Flask, render_template, request, jsonify
import joblib

app = Flask(__name__)
model = joblib.load("model/model.pkl")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    user_input = request.json["message"]
    prediction = model.predict([user_input])[0]
    return jsonify({"diagnosis": prediction})

if __name__ == "__main__":
    app.run(debug=True)
