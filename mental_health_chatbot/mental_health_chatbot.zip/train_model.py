import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline

# Load dataset
df = pd.read_csv("mental_health.csv")  # Rename CSV if needed

# Combine relevant columns into a single text input
df["text"] = df[["symptoms", "diagnosis", "treatment"]].fillna("").agg(" ".join, axis=1)

# Encode label (example: diagnosis column)
y = df["diagnosis"]
X = df["text"]

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create pipeline
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer()),
    ('clf', RandomForestClassifier())
])

# Train model
pipeline.fit(X_train, y_train)

# Save model
joblib.dump(pipeline, "app/model/model.pkl")
print("Model trained and saved.")
